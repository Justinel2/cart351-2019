<?php try {
    /**************************************
    * Create databases and                *
    * open connections                    *
    **************************************/

    // Create (connect to) SQLite database in file
    $file_db = new PDO('sqlite:./db/submissionsDB.db');
    // Set errormode to exceptions
    /* .. */
    $file_db->setAttribute(PDO::ATTR_ERRMODE,
                            PDO::ERRMODE_EXCEPTION);
    // echo('OPENED');

    $arrayFlags = array();

    $sql_select='SELECT * FROM flags';
    // the result set
    $result = $file_db->query($sql_select);
    if (!$result) die("Cannot execute query.");

    // // get a row...
    // while($row = $result->fetch(PDO::FETCH_ASSOC)) {
    //   foreach ($row as $key=>$entry) {
    //   }
    // }//end while
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
      $arrayFlags[] = $row['flag'];
    }
  }
  catch(PDOException $e) {
    // Print PDOException message
    echo $e->getMessage();
  } ?>

<script type="text/javascript">


let $codeInputArea;

let code = "0";

// let geocoder;
let steps = 1;
let map;
let feature;
let lat, lng;
let marker;
let markerIcon;
let enableMarker = false;

let newFlags = [];

let flagsFromDB = [];
let flags = [];


$(document).ready(setup);

console.log("ready");

function setup() {
  map = new L.Map('map', {zoomControl: true});

  $codeInputArea = $('#codeInputArea');

  $('#nav-icon').on('click', goMenu);
  $('#abo-link').on('click', goHome);
  $('#res-link').on('click', goHome);
  $('#cont-link').on('click', goHome);
  $('#home-link').on('click', goHome);
  $('#submit-link').on('click', goForm);
  $('#access-link').on('click', goId);

  $('.plus-x').on('click', handleMarking);

  $('textarea').on('click', function() {
    $(this).css('border-bottom', 'none');
  });

  $(".toggleTextSize").on('focus blur', toggleFocusText);

  $("textarea").keyup(function(e) {
      while($(this).outerHeight() < this.scrollHeight + parseFloat($(this).css("borderTopWidth")) + parseFloat($(this).css("borderBottomWidth"))) {
          $(this).height($(this).height()+1);
      };
  });

  markerIcon = L.icon({
    iconUrl: '../images/red-dot-marker.png',

    iconSize:     [63, 50], // size of the icon
    iconAnchor:   [25, 25], // point of the icon which will correspond to marker's location
});

  $('#flagsTextArea').on('click', flagAutocomplete);
  $('.deleteFlag').on('click', deleteFlag);
  flagsFromDB = <?php echo json_encode($arrayFlags);?>;
  flagsFromDB = checkForDoubles(flagsFromDB);

  $('#access-button').on('click', signIn);
  // $('#maxi-button').on('click', maximizeEntry);

}

function goHome() {
  console.log("gohome");
  $('#nav-icon').removeClass("open");
  $('#homepage').css('display', 'block');
  $('#nav-menu').css('display', 'none');
  $('.page').css('display', 'none');
  $('#nav-icon span').css('background-color', 'black')

  if ($(this).attr("id") === "res-link") {
    $('html, body').animate({
        scrollTop: $('#ressources-section').offset().top
    }, 500);
  }
  else if ($(this).attr("id") === "cont-link") {
    $('html, body').animate({
        scrollTop: $('#contact-section').offset().top
    }, 500);
  }
  else {
    $('html, body').animate({
        scrollTop: $('#about-section').offset().top
    }, 500);
  }
}

function goMenu() {
  $(this).toggleClass('open');
  if ($( this ).hasClass( "open" )) {
    $('#nav-menu').css('display', 'block');
    $('#nav-icon span').css('background-color', 'white')
  }
  else {
    $('#nav-menu').css('display', 'none');
    $('#nav-icon span').css('background-color', 'black')
  }
}

function goForm() {
  steps = 1;
  $('.geocoder-control-input').css('display','block');
  $('#nav-icon').removeClass("open");
  $('#homepage').css("display", "none");
  $('#submissions').css('display',"none");
  $('#form').css('display',"block");
  $('#signIn').css('display',"none");
  $('#nav-menu').css('display', 'none');
  $('#nav-icon span').css('background-color', 'black')
  $(".submitSection").css('display',"block");
  if (steps === 1) {
    $('buttonP').css('opacity','0');
  }

  console.log("go form");
  load_map();
  formSteps();
}

function goId() {
  $('.geocoder-control-input').css('display','none');
  $('#nav-icon').removeClass("open");
  $('#homepage').css("display", "none");
  $('#form').css('display',"none");
  $('#signIn').css('display',"block");
  $('#nav-menu').css('display', 'none');
  $('#nav-icon span').css('background-color', 'black')
  $(".submitSection").css('display',"none");
  console.log("go form");
}

function signIn() {
  $("#incorrect-code").css('display',"none");
  $('#nav-icon').removeClass("open");

  if ($codeInputArea.val() === "0") {
    $('#signIn').css('display',"none");
    $('#nav-menu').css('display', 'none');
    $('#submissions').css('display',"block");
    $("#submissions").load("../php/viewResults.php");
    $(".submitSection").css('display',"none");
  }
  else {
    $("#incorrect-code").css('display',"block");
  }
}

// function maximizeEntry() {
//   console.log("maximize!");
//   $('#maxi').css('display',"block");
// }

function decreaseSteps() {
  if (steps > 1) {
    steps--;
  }
  else {
    $('#buttonP').css('opacity',"0");
  }
  formSteps();
}

function incrementSteps() {
  if (steps < 4) {
    steps++;
  }
    else if (steps === 4) {
      $('#buttonS').css('display',"block");
      $('#buttonP').css('opacity',"0");
      $('#buttonN').css('display',"none");
      steps++;
    }
    // else {
    //   steps++;
    // }
    console.log(steps);
  formSteps();
}

function formSteps() {
  if (steps === 1) {
    console.log("1");
    $('.geocoder-control-input').css('display','block');
    $("#verification-form-area").css('display', 'none');
    $('#search').css('display',"block");
    $('#fac').css('display',"none");
    $('#flags').css('display',"none");
    $('#buttonP').css('opacity',"0");
    $('#buttonN').css('opacity','1');
    $("#confirm").css('display', 'none');
  }
  else if (steps === 2) {
    console.log("2");
    $("#verification-form-area").css('display', 'none');
    $('#fac').css('display',"block");
    $('#flags').css('display',"none");
    $('#search').css('display',"none");
    $('#buttonP').css('opacity',"1");
    $('.submitSection').css('margin-top',"101vh");
  }
  else if (steps === 3) {
    console.log("3");
    $("#verification-form-area").css('display', 'none');
    $('#flags').css('display',"block");
    $('#fac').css('display',"none");
    $('#buttonP').css('opacity',"1");
  }
  else if (steps === 4) {
    $("#verification-form-area").css('display', 'block');
    $('#fac').css('display',"none")
    $('#flags').css('display',"none");
    $('#search').css('display',"none");
    $('#buttonP').css('opacity',"1");
    $('#buttonN').css('opacity',"0");
    $('#buttonS').css('display',"block");
  }
}

function load_map() {
  var osmUrl = 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    osmAttribution = 'Map data &copy; 2012 <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
    osm = new L.TileLayer(osmUrl, {maxZoom: 18, attribution: osmAttribution});

  map.setView(new L.LatLng(45.52485408283562, -73.5948758640825), 10).addLayer(osm);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
     attribution: '&copy; <a href="https://osm.org/copyright">OpenStreetMap</a> contributors'
   }).addTo(map);
   var searchControl = L.esri.Geocoding.geosearch().addTo(map);
   var results = L.layerGroup().addTo(map);
   searchControl.on('results', function (data) {
     results.clearLayers();
     for (var i = data.results.length - 1; i >= 0; i--) {
       // results.addLayer(L.marker(data.results[i].latlng));
     }
   });

  map.on('click', function(e) {
    console.log("Lat, Lon : " + e.latlng.lat + ", " + e.latlng.lng)
    lat = e.latlng.lat;
    lng = e.latlng.lng;
    addMarker(e.latlng);
  });
}

function addr_search() {
  var inp = document.getElementById("addr");
  $.getJSON('http://nominatim.openstreetmap.org/search?format=json&limit=5&q=' + inp.value, function(data) {
    var items = [];
    $.each(data, function(key, val) {
        bb = val.boundingbox;
        items.push("<li><a href='#' onclick='chooseAddr(" + bb[0] + ", " + bb[2] + ", " + bb[1] + ", " + bb[3]  + ", \"" + val.osm_type + "\");return false;'>" + val.display_name + '</a></li>');
    });
            $('#results').empty();
    if (items.length != 0) {
        $('<p>', { html: "Search results:" }).appendTo('#results');
        $('<ul/>', {
            'class': 'my-new-list',
            html: items.join('')
        }).appendTo('#results');
    } else {
        $('<p>', { html: "No results found" }).appendTo('#results');
    }
  });
}

function enableMarking() {
  enableMarker = true;
}

function handleMarking() {
  if ($(this).hasClass("closed")) {
     $(this).toggleClass("opened");
     enableMarking()
  } else {
    $(this).addClass("closed");
    deleteMarker()
  }
}

function addMarker(latlng) {
  if (enableMarker === true) {
    marker = L.marker([lat,lng], { title: "My marker", icon: markerIcon }).addTo(map);

    L.esri.Geocoding.reverseGeocode()
      .latlng([lat,lng])
      .run(function (error, result, response) {
    $('#cityForm').val(result.address.City);
    $('#latForm').val(lat);
    $('#lngForm').val(lng);
  });
    enableMarker = false;
    $('.plus-x').toggleClass("closed");
  }
}

function deleteMarker() {
  map.removeLayer(marker);
  $('.plus-x').toggleClass("opened");
}

function flagAutocomplete() {
  $( "#flagsTextArea" ).autocomplete({
    source: flagsFromDB
  });
}

function toggleFocusText(){
  console.log("toggleTEXTTT");
    if($(this).prev('label').hasClass("empty") || $(this).val().length != 0){
      console.log("smalll");
       $(this).prev('label').toggleClass('written');
    }
    else {
      $(this).prev('label').toggleClass('empty');
    }
}

function addTagToList() {
  console.log("addtag");
  if ($('#flagsTextArea').val() != "") {
    console.log("not null");
    let flag = $('#flagsTextArea').val();
    // CAPITALIZE EACH WORD
    let arr = flag.split(' ');
    let result = "";
    for (var x=0; x<arr.length; x++)
        result+=arr[x].substring(0,1).toUpperCase()+arr[x].substring(1)+' ';
    flag = result.substring(0, result.length-1);
    $("#flagsDisplayArea").append("<div class=\"bubbleFlag\"><p>" + flag + "</p><button type=\"button\" onClick=\"deleteFlag(this)\">x</button></div>");
    $('#flagsTextArea').val("");
    updateFlagArray();
  }
}

function deleteFlag(elem) {
  $(elem).parent('div').remove();
  updateFlagArray();
}

function updateFlagArray() {
  flags = [];
  $('.bubbleFlag').each (function() {
    flags.push($('p',this).text());
  });
  flags = checkForDoubles(flags);
  console.log(flags);
  console.log(flags.length);
  let flagsString = "";
  for (var i = 0; i < flags.length; i++) {
    flagsString += "/" + flags[i];
  }
  let newArr = [];
  let combinedFlags = checkForDoubles($.merge(flags, flagsFromDB));
  // console.log(combinedFlags);
  newFlags = checkForNew($.merge(combinedFlags, flagsFromDB));
  // checkForNew($.merge(checkForDoubles(combinedFlags),flagsFromDB),newFlags);
  console.log(newFlags);
  let newFlagsString = "";
  for (var i = 0; i < newFlags.length; i++) {
    newFlagsString += "/" + newFlags[i];
  }

  $('#flagListForm').val(flagsString);
  console.log(flagsString);
  $('#newFlagListForm').val(newFlagsString);
  // console.log(newString);
}

function checkForDoubles(list) {
  var result = [];
  $.each(list, function(i, e) {
    if ($.inArray(e, result) == -1) result.push(e);
  });
  return result;
}

function checkForNew(currArr) {
  var newArr = [];
$.each(currArr , function (i, el) {
    if ($.inArray(el, newArr ) === -1) {
        newArr.push(el);
    }
    else {
        var index = newArr.indexOf(el);
        if(index > -1){
           newArr.splice(index, 1);
        }
    }
});
  return newArr;
}
</script>
