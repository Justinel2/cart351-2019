<?php
// put required html mark up
echo"<html>\n";
echo"<head>\n";
echo"<title> FLAG DATABASE </title> \n";
//include CSS Style Sheet
// echo "<link rel='stylesheet' type='text/css' href='../css/viewStyle.css'>";
echo"</head>\n";
// start the body ...
echo"<body>\n";

// place body content here ...
try {
    /**************************************
    * Create databases and                *
    * open connections                    *
    **************************************/

    // Create (connect to) SQLite database in file
    $file_db = new PDO('sqlite:../db/submissionsDB.db');
    // Set errormode to exceptions
    /* .. */
    $file_db->setAttribute(PDO::ATTR_ERRMODE,
                            PDO::ERRMODE_EXCEPTION);
    // echo('OPENED');


    $sql_select_mini='SELECT * FROM flagSubmissions';
    // the result set
    $result_mini = $file_db->query($sql_select_mini);
    if (!$result_mini) die("Cannot execute query.");

    $lat_array = array();
    $lng_array = array();

    // fetch first row ONLY...
    // $row = $result->fetch(PDO::FETCH_ASSOC);
    // var_dump($row);

    echo"<div id='view-map'>";
    echo"</div>";

    echo"<div id='back'>";
    // get a row...
    while($row = $result_mini->fetch(PDO::FETCH_ASSOC)) {
      echo "<div class ='outer'>";
      echo "<div class ='content'>";
      // go through each column in this row
      // retrieve key entry pairs
      foreach ($row as $key=>$entry) {
        //if the column name is not 'image'
        if ($entry != "") {
          if($key == "name" || $key == "age" || $key == "city") {
            // echo the key and entry
            echo "<p class='".$key."'>".$entry."</p>";
          }
          else if ($key == "flag") {
            echo"<div id='flags'>";
            $flag_array = explode('/',$entry);
            for ($i=1; $i < count($flag_array); $i++) {
              $temp = $flag_array[$i];
              echo "<div class='bubbleFlag'><p>".$temp."</div>";
              // $temp = $flag_es_ARRAY[$i];
              // $temp_es = $file_db->quote($temp);
            }
            echo"</div>";
          }
          else if ($key == "lat") {
            // echo($entry);
            array_push($lat_array,$entry);
          }
          else if ($key == "lng") {
            // echo($entry);
            array_push($lng_array,$entry);
          }
        }
      }
      echo "</div>";
      echo "</div>";
    }//end while


    echo"</div>";


  }
  catch(PDOException $e) {
    // Print PDOException message
    echo $e->getMessage();
  }


echo"</body>\n";
echo"</html>\n";

?>

<script type="text/javascript">

  let lats = [];
  let lngs = [];
  let viewMarkers = [];

  $(document).ready(setup);

  function setup() {
    console.log("script works");
    map = new L.Map('view-map', {zoomControl: true});
    load_map();
  }

  function load_map() {

    var osmUrl = 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      osmAttribution = 'Map data &copy; 2012 <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
      osm = new L.TileLayer(osmUrl, {maxZoom: 18, attribution: osmAttribution});

    map.setView(new L.LatLng(45.52485408283562, -73.5948758640825), 12).addLayer(osm);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
       attribution: '&copy; <a href="https://osm.org/copyright">OpenStreetMap</a> contributors'
     }).addTo(map);
     var searchControl = L.esri.Geocoding.geosearch().addTo(map);
     $('.geocoder-control-input').css('display','none');
     var results = L.layerGroup().addTo(map);
     searchControl.on('results', function (data) {
       results.clearLayers();
       for (var i = data.results.length - 1; i >= 0; i--) {
       }
     });
     addMarkers();


     function addMarkers() {
       lats = <?php echo json_encode($lat_array);?>;
       console.log(lats);
       lngs = <?php echo json_encode($lng_array);?>;
       console.log(lngs);

       for (var i = 0; i < lats.length; i++) {
         L.marker([lats[i],lngs[i]], {icon: markerIcon }).addTo(map);
       }
   //     $.ajax({
   //      type : 'GET',
   //      url : "viewResults.php",
   //      data : data,
   //      dataType: 'json',
   //      success : function(result) {
   //        console.log(result);
   //      },
   //    error : function () {
   //       alert("error");
   //    }
   // })


 }
}

</script>
