<?php
try {
    /******************************************
    * Create databases and  open connections*
    ******************************************/

    // Create (connect to) SQLite database in file
    $file_db = new PDO('sqlite:../db/testFiveDB.db');
    // $file_db_B = new PDO('sqlite:../db/flagsDB.db');
  // Set errormode to exceptions
    $file_db->setAttribute(PDO::ATTR_ERRMODE,
                            PDO::ERRMODE_EXCEPTION);
    echo("opened or connected to the database");
    // $file_db_B->setAttribute(PDO::ATTR_ERRMODE,
    //                         PDO::ERRMODE_EXCEPTION);
    // echo("opened or connected to the database flagsDB");

    $theQuery_A = 'CREATE TABLE flagSubmissions (pieceID INTEGER PRIMARY KEY NOT NULL, name TEXT, age INT, occupation TEXT, physDesc TEXT, platform TEXT, dateEvent DATE, timeEvent TEXT, lat DECIMAL(10, 8), lng DECIMAL(11, 8), city TEXT, flag TEXT, story TEXT)';
    $theQuery_B = 'CREATE TABLE flags (pieceID INTEGER PRIMARY KEY NOT NULL, flag TEXT)';
    $theQuery_C = 'CREATE TABLE flagSubmissionRelation (pieceID INTEGER PRIMARY KEY NOT NULL, flagName TEXT, subID INT)';

    $file_db ->exec($theQuery_A);
    // if everything executed error less we will arrive at this statement
    echo ("Table flagSubmissions created successfully<br \>");
    $file_db ->exec($theQuery_B);
    // if everything executed error less we will arrive at this statement
    echo ("Table flagsDB created successfully<br \>");
    $file_db ->exec($theQuery_C);
    // if everything executed error less we will arrive at this statement
    echo ("Table flagSubmissionRelation created successfully<br \>");
      // Close file db connection
      $file_db = null;
   }

catch(PDOException $e) {
    // Print PDOException message
    echo $e->getMessage();
  }

  ?>
