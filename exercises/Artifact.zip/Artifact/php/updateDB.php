<?php
try {
    /**************************************
    * Create databases and                *
    * open connections                    *
    **************************************/

    // Create (connect to) SQLite database in file
    $file_db_B = new PDO('sqlite:../db/submissionsDB.db');
    // Set errormode to exceptions
    /* .. */
    $file_db_B->setAttribute(PDO::ATTR_ERRMODE,
                            PDO::ERRMODE_EXCEPTION);


    //DELETE ALL
    $sql_delete="DELETE FROM flags";
    $file_db_B ->exec($sql_delete);
    echo ("DELETION OF all entries of flags successful");

    $sql_delete="DELETE FROM flagSubmissions";
    $file_db_B ->exec($sql_delete);
    echo ("DELETION OF all entries of flagSubmissions successful");

    // $name_es = "test";
    // $age_es = "12";
    // $occupation_es = "test";
    // $physDesc_es = "test";
    // $platform_es = "test";
    // $date_es = "";
    // $time_es = "test";
    // $lat_es = "12";
    // $lng_es = "12";
    // $city_es = "test";
    // $flag_es = "test";
    // $newFlag_es = "test";
    // $story_es = "test";
    //
    // echo("hello");
    //
    // $queryInsert_sub ="INSERT INTO flagSubmissions (name, age, occupation, physDesc, platform, dateEvent, timeEvent, lat, lng, city, flag, newFlag, story)VALUES ($name_es,$age_es,$occupation_es,$physDesc_es,$platform_es,$date_es,$time_es,$lat_es,$lng_es,$city_es,$flag_es, $newFlag_es, $story_es)";
    // $file_db_B->exec($queryInsert_sub);
    // echo($name_es);

    // UPDATE
    // $sql_update="UPDATE flags SET title = 'Untitled' WHERE pieceID =1";
    // // again we do error checking when we try to execute our SQL statements on the db
    // //$file_db_B ->exec($sql_update);

    // DELETE AN ENTRY
    // $sql_delete="DELETE FROM artCollection WHERE artist = 'Martha'";
    // //$file_db_B ->exec($sql_delete);
    // //echo ("DELETION OF entry in artCollection successful");

    // ADDING/DELETING A COLUMN
    // $ran_num = rand(5,100);
   // //echo($ran_num);
   // // add a new column + default value where we use the php variable
   // $sql_alter = "ALTER TABLE artCollection ADD COLUMN ran_num INTEGER NOT NULL DEFAULT '$ran_num'";
   // $file_db_B ->exec($sql_alter);
   // echo ("ALTERATION OF entry in artCollection successful");

    // if we reach this point then all the data has been updated successfully.
    echo ("UPDATE OF table called flags successful");

  }
  catch(PDOException $e) {
    // Print PDOException message
    echo $e->getMessage();
  }
?>
