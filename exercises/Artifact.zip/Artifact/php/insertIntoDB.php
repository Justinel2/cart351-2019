<?php

try {
    /**************************************
    * Create databases and                *
    * open connections                    *
    **************************************/

    // Create (connect to) SQLite database in file
    $file_db = new PDO('sqlite:../db/submissionsDB.db');
    // Set errormode to exceptions
    /* .. */
    $file_db->setAttribute(PDO::ATTR_ERRMODE,
                            PDO::ERRMODE_EXCEPTION);

    $queryArray_A = array(
  	   "INSERT INTO flags (flag) VALUES ('Sexual Harassment')",
       "INSERT INTO flags (flag) VALUES ('Racism')",
       "INSERT INTO flags (flag) VALUES ('Xenophobia')",
       "INSERT INTO flags (flag) VALUES ('Sexual Assault')",
       "INSERT INTO flags (flag) VALUES ('Emotional Manipulation')",
       "INSERT INTO flags (flag) VALUES ('Physical Assault')",
       "INSERT INTO flags (flag) VALUES ('Intimidation')",
       "INSERT INTO flags (flag) VALUES ('Abuse of Power')",
       "INSERT INTO flags (flag) VALUES ('Blackmail')",
       "INSERT INTO flags (flag) VALUES ('Gang Rape')",
       "INSERT INTO flags (flag) VALUES ('Revenge Porn')",
       "INSERT INTO flags (flag) VALUES ('Transphobia')",
       "INSERT INTO flags (flag) VALUES ('Fatphobia')",
       "INSERT INTO flags (flag) VALUES ('Homophobia')",
       "INSERT INTO flags (flag) VALUES ('Emotional Violence')",
       "INSERT INTO flags (flag) VALUES ('Physical Violence')",
       "INSERT INTO flags (flag) VALUES ('Sexual Violence')"
     );

      // go through each entry in the array and execute the INSERT query statement....
      for($i =0; $i< count($queryArray_A); $i++)
      {
  	     $file_db->exec($queryArray_A[$i]);
         echo $queryArray_A[$i];
         echo($i);
      }

      $sql_select='SELECT COUNT(*) FROM flags';
      // the result set
      $result = $file_db->query($sql_select);
      if (!$result) die("Cannot execute query.");
      while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        var_dump($row);
      }


  // $queryArray_B = array(
  //    "INSERT INTO flagSubmissions (name) VALUES ('Test')",
  //    "INSERT INTO flagSubmissions (name) VALUES ('Test2')"
  //  );
  //
  //  // go through each entry in the array and execute the INSERT query statement....
  //  for($i =0; $i< count($queryArray_B); $i++)
  //  {
  //     $file_db->exec($queryArray_B[$i]);
  //     echo $queryArray_B[$i];
  //  }

   // if we reach this point then all the data has been inserted successfully.
   echo ("INSERTION OF ENTRY into flags Table successful");
   }

  catch(PDOException $e) {
    // Print PDOException message
    echo $e->getMessage();
  }
?>
