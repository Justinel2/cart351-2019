<?php
//check if there has been something posted to the server to be processed
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
// need to process
 $name = $_POST['a_name'];
 $age = $_POST['a_age'];
 $occupation = $_POST['a_occupation'];
 $physDesc = $_POST['a_physDesc'];
 $platform = $_POST['a_platform'];
 $date = $_POST['a_date'];
 $time = $_POST['a_time'];
 $lat = $_POST['a_lat'];
 $lng = $_POST['a_lng'];
 $city = $_POST['a_city'];
 $flag = $_POST['a_flag'];
 $newFlag = $_POST['a_newFlag'];
 $story = $_POST['a_story'];

   try {
       /**************************************
       * Create databases and                *
       * open connections                    *
       **************************************/

       // Create (connect to) SQLite database in file
       $file_db = new PDO('sqlite:db/submissionsDB.db');
       // Set errormode to exceptions
       /* .. */
       $file_db->setAttribute(PDO::ATTR_ERRMODE,
                               PDO::ERRMODE_EXCEPTION);


      $name_es = $file_db->quote($name);
      $age_es = $file_db->quote($age);
      $occupation_es = $file_db->quote($occupation);
      $physDesc_es = $file_db->quote($physDesc);
      $platform_es = $file_db->quote($platform);
      $date_es = $file_db->quote($date);
      $time_es = $file_db->quote($time);
      $lat_es = $file_db->quote($lat);
      $lng_es = $file_db->quote($lng);
      $city_es = $file_db->quote($city);
      $flag_es = $file_db->quote($flag);
      $newFlag_es = $file_db->quote($newFlag);
      $story_es = $file_db->quote($story);

      //Make arrays
      $newFlag_es_ARRAY = explode('/',$newFlag_es);
      $flag_es_ARRAY = explode('/',$flag_es);


      $queryInsert_sub ="INSERT INTO flagSubmissions (name, age, occupation, physDesc, platform, dateEvent, timeEvent, lat, lng, city, flag, story)VALUES ($name_es,$age_es,$occupation_es,$physDesc_es,$platform_es,$date_es,$time_es,$lat_es,$lng_es,$city_es,$flag_es, $story_es)";
      $file_db->exec($queryInsert_sub);

     for ($i=1; $i < count($newFlag_es_ARRAY); $i++) {
       $temp = $newFlag_es_ARRAY[$i];
       $temp_es = $file_db->quote($temp);
       $queryInsert_newFlags = "INSERT INTO flags(flag) VALUES ($temp_es)";
       $file_db->exec($queryInsert_newFlags);
     }

     for ($i=1; $i < count($flag_es_ARRAY); $i++) {
       $temp = $flag_es_ARRAY[$i];
       $temp_es = $file_db->quote($temp);
       $queryInsert_flags = "INSERT INTO flagSubmissionRelation (flagName,subID) VALUES ($temp_es,)";
     }

    }
     catch(PDOException $e) {
       // Print PDOException message
       echo $e->getMessage();
     }

    exit;

}//POST
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>FLAG</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="libs/leaflet.css">
    <script src="libs/leaflet.js"></script>
    <script src="libs/esri-leaflet.js"></script>
    <link rel="stylesheet" href="libs/esri-leaflet-geocoder.css">
    <script src="libs/esri-leaflet-geocoder.js"></script>
    <script src="libs/jquery-3.4.1.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  </head>
  <body>
    <div id="header">
      <div class="logo">
        <a id="home-link">FLAG</a>
      </div>
      <div id="nav-icon">
        <span></span><span></span><span></span><span></span><span></span><span></span>
      </div>
      <div id="nav-menu">
        <a class="menu-link section-link" id="abo-link">ABOUT</a>
      <a class="menu-link section-link" id="res-link">RESOURCES</a>
        <a class="menu-link" id="submit-link">SUBMIT</a>
        <a class="menu-link" id="access-link">ACCESS</a>
        <a class="menu-link section-link" id="cont-link">CONTACT</a>
      </div>
    </div>
    <div class="submitSection">
      <button class="sub-links" type="button" onclick="decreaseSteps();" id="buttonP">PREC</button>
      <button class="sub-links" type="button" onclick="incrementSteps();" id="buttonN">NEXT</button>
      <p class = "sub"><input form="insertSubmission" type = "submit" name = "submit" value = "SUBMIT" id ="buttonS"/></p>
    </div>
    <div id="homepage">
      <div class="home-section" id="about-section" name="about-section">
        <p>FLAG is a web-based project that allows users to anonymously flag or report an individual for a
          time-specific and/or ongoing aggression. Because the users can choose or create their own flags
          (acting in the same principle as tags), the reports can be specific and can encompass micro to macro
          aggressions. </p>
        <p>The objective is to create an anonymous, inclusive and safe
          environment that is meant to identify patterns of aggression in individuals/spaces/locations and to,
          hopefully, help prevent future incidents.</p>
        <p>To add protection to the flaggers, the visualization of the flags is restricted to users detaining a valid code.
          The codes are for now distributed by mouth-to-ear, so to allow access to trusted individuals. </p>
        <div class="sugg-links">
          <a id="submit-link" onclick='goForm();'>Submit a FLAG</a>
          <a id="access-link" onclick='goId();'>Access the Database</a>
        </div>
        <div class="home-section" id="terr-ack">
          <p>FLAG acknowledges that this platform's creation and maintenance is on the traditional island of Tiohtiá:ke (commonly known as Montreal), territory
          of The Kanien’kehá:ka Nation. You can find more information on the stolen Lands and how to help decolonize at:

            <a href="https://www.native-land.ca">Native Land</a>
            <a href="https://reconciliationcanada.ca/">Reconciliation Canada</a>
            <a href="https://www.faq-qnw.org/en/about-us/">Quebec Native Women Inc.</a>

        </div>
      </div>
      <div class="home-section" id="ressources-section" name="ressources-section">
        <p>Denonciating a traumatic experience on this platform event can be relieving and empowering.
        Yet, this platform should not be the only tool you refer yourself to.  <span id="red">Please go seek help from a professional.</span>
        Here is a list of some ressources based in Montreal:</p>

        <h3>24H EMERGENCY LINES</h3>
        <a class="site" href="https://spvm.qc.ca/">Ambulance, Police, Fire - 911</a>
        <a class="site" href="https://www.quebec.ca/en/health/finding-a-resource/info-sante-811/">Info Santé (Info Health) - 811</a>


        <h3>QUEBEC 24H HELP LINES</h3>
        <a class="site" href="http://cvasm.org/en/services-ligne-telephonique">Montreal Sexual Assault Centre Helpline</a> - <a class="tel" href="tel:1-888-933-9007">1 888 933-9007</a>
        <a class="site" href="https://suicideactionmontreal.org/en/i-need-help/">Suicide Action Montreal</a> - <a class="tel" href="tel:1-866-277-3553">1 866 277-3553</a>
        <a class="site" href="http://www.atq1980.org/">Aide aux Trans du Québec</a> - <a class="tel" href="tel:1-855-909-9038 #1">1 855 909-9038 #1</a>
        <a class="site" href="http://www.telaide.org/eng/welcome.php">Tel-Aide</a> - <a class="tel" href="tel:514-935-1101">514 935-1101</a>
        <a class="site" href="http://www.sosviolenceconjugale.ca/">S.O.S Violence Conjugale</a> - <a class="tel" href="tel:1-800-363-9010">1 800 363-9010</a>
        <a class="site" href="http://www.drogue-aidereference.qc.ca/www/index.php?locale=en-CA">Drugs: Help and Referral</a> - <a class="tel" href="1-800-265-2626">1 800 265-2626</a>

        <h3>SUPPORT/INFORMATION</h3>
        <a class="site" href="http://cvasm.org/en/">Montreal Sexual Assault Centre</a>
        <a class="site" href="https://www.ccglm.org/index.php?langue=en">Montreal LGBTQ+ Community Center</a>
        <a class="site" href="https://www.faq-qnw.org/en/about-us/">Quebec Native Women Inc.</a>
        <a class="site" href="http://www.scf.gouv.qc.ca/index.php?id=61&L=1">Secretariat à la Condition Féminine</a>

      </div>
      <div class="home-section" id="contact-section" name="contact-section">
        <p>Do not hesitate to get in touch if you have any suggestion, comments or questions.</p>
        <a href="mailto:flag@example.com">flag@example.com</a>
      </div>

    </div>
    <div class="page" id="form">
      <form class="container" id="insertSubmission" action="" enctype ="multipart/form-data">
        <fieldset>
            <div id="fac">
              <h1>INDIVIDUAL/GROUP</h1>
              <p><label class="empty">Name(s)/Nickname(s): </label><input type="text" size="24" name = "a_name" class="toggleTextSize"></p>
              <p><label class="empty">Age: </label><input type="number" size="2" maxlength="2" name = "a_age" class="toggleTextSize"></p>
              <p><label class="empty">Occupation: </label><input type = "text" size="24" name = "a_occupation" class="toggleTextSize"></p>
              <p><label class="empty">Physical Description: </label><textarea form="insertSubmission" name="a_physDesc" rows="1" cols="50" class="toggleTextSize"></textarea></p>
              <p><label class="empty">Where you met: </label><input type = "text" size="16"name = "a_platform" class="toggleTextSize"></p>

              <h1>INCIDENT</h1>
              <p><label class="empty">Date: </label><input type="date" name="a_date" class="toggleTextSize"></p>
              <p><label class="empty">Time: </label><input type = "text" size="16" name = "a_time" class="toggleTextSize"></p>
              <p><label class="empty">This is what happened: </label><textarea form="insertSubmission" name="a_story" rows="1" cols="50" class="toggleTextSize"></textarea></p>
            </div>
            <div id="search">
              <!-- <p><label>City:</label><input type = "text" size="24" maxlength = "40" name = "addr" id="addr" required></p> -->
              <div class="plus-x closed">
                <div class="circle">
                  <div class="cross-horizontal"></div>
                  <div class="cross-vertical"></div>
                </div>
              </div>
              <div id="map"></div>
             <div class="hide">
                 <p><label>lat</label><input type="number" step="any" size="24" maxlength = "40" name = "a_lat" id="latForm" required></p>
                 <p><label>lng</label><input type="number" step="any" size="24" maxlength = "40" name = "a_lng" id="lngForm" required></p>
                 <p><label>city</label><input type = "text" size="24" maxlength = "40" name = "a_city" id="cityForm" required></p>
                 <p><label>FlagList</label><input type = "text" size="24" maxlength = "40" name = "a_flag" id="flagListForm" required></p>
                 <p><label>NewFlags</label><input type = "text" size="24" maxlength = "40" name = "a_newFlag" id="newFlagListForm"></p>
               </div>
		        </div>
            <div id="flags">
              <h1>FLAG(S)</h1>
              <div id="research-flags-area">
                <p><label class="empty">Enter a FLAG: </label><input type = "text" size="24" maxlength = "40" id="flagsTextArea" class="toggleTextSize"></p>
                <button id="addFlagButton" type="button" name="buttonAddTag" onclick="addTagToList();">+</button>
              </div>
              <div id="flagsDisplayArea"></div>
            </div>
            <div id="verification-form-area">
              <p>Before submitting, please review the previous sections.</p>
              <p>When you feel like all the informations are exact (to the best of your knowledge/memory), click on the link below.</p>
              <p id="confirm" class="feedback-message">Thank you for submitting! <a href="index.php">BACK TO HOMEPAGE</a></p>
            </div>
         </fieldset>
      </form>
    </div>
    <div class="page" id="signIn">
      <div class="identification">
        <fieldset>
          <p><label>To view the flags, you must have a valid code. Please enter it below:</label></p><input id="codeInputArea" type="text" size="24" maxlength = "40" name = "a_name" required> </p>
          <input id="access-button" class="sub-links" type = "submit" name = "submit" value = "ACCESS"/>
          <p id="incorrect-code" class="feedback-message">Sorry, the code you entered is incorrect.</p>
        </fieldset>
      </div>
    </div>
    <div class="page" id="submissions"></div>

<script>
// here we put our JQUERY
$(document).ready (function(){

    $("#insertSubmission").submit(function(event) {
       //stop submit the form, we will post it manually. PREVENT THE DEFAULT behaviour ...
      event.preventDefault();
     console.log("button clicked");
     let form = $('#insertSubmission')[0];
     let data = new FormData(form);
    // Display the key/value pairs
    // to access the data in the formData Object ... (not this is ALL TEXT ... )
    // as key -value pairs
    //Object.entries() method in JavaScript returns an array consisting of
    //enumerable property [key, value] pairs of the object.
    for (let valuePairs of data.entries()) {
    console.log(valuePairs[0]+ ', ' + valuePairs[1]);
  }

  $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: "index.php",
            data: data,
            processData: false,//prevents from converting into a query string
            contentType: false,
            cache: false,
            timeout: 600000,
            success: function (response) {
            //reponse is a STRING (not a JavaScript object -> so we need to convert)
            console.log("we had success!");
            $("#verification-form-area").css('display', 'block');
            $("#confirm").css('display', 'block');
            $('#buttonS').css('display',"none");
            console.log(response);
            //use the JSON .parse function to convert the JSON string into a Javascript object
            // let parsedJSON = JSON.parse(response);
            // console.log(parsedJSON);
            // displayResponse(parsedJSON);
           },
           error:function(){
          console.log("error occurred");
        }
      });
   });

});
// module.export { flagsFromDB };
</script>
<?php include 'js/script.php';?>
</body>
</html>
